"""SAFIRE services package."""
