"""SAFIRE model adapters."""
