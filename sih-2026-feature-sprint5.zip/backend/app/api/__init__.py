"""SAFIRE API route modules."""
