"""SAFIRE Pydantic schemas."""
