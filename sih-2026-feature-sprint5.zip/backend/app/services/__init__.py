"""SAFIRE backend services."""
