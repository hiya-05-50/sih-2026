"""Sprint 5 – DNS Query Monitor.

Thin monitoring layer that checks whether a DNS resolution request
targets an allowed zone before resolving.  All queries — allowed
and blocked — are recorded through the SovereigntyLogger.

This does NOT replace OS-level DNS; it is an *application-level*
check that SAFIRE services call before performing hostname
resolution or outbound HTTP requests.
"""

from __future__ import annotations

import logging
import socket
from typing import Optional, Tuple

from shared.enums import (
    SovereigntyEventSeverity,
    SovereigntyEventType,
)
from app.services.sovereignty.network_enforcer import NetworkEnforcer
from app.services.sovereignty.sovereignty_logger import SovereigntyLogger

logger = logging.getLogger(__name__)


class DNSMonitor:
    """Application-level DNS query gate.

    Parameters
    ----------
    sovereignty_logger:
        Logger for sovereignty events.
    network_enforcer:
        The enforcer whose zone classification decides whether
        a DNS lookup is permitted.
    """

    def __init__(
        self,
        sovereignty_logger: SovereigntyLogger,
        network_enforcer: NetworkEnforcer,
    ) -> None:
        self._sov_logger = sovereignty_logger
        self._enforcer = network_enforcer

    def check_dns_query(
        self,
        hostname: str,
    ) -> Tuple[bool, Optional[str]]:
        """Check whether resolving *hostname* is allowed.

        Returns ``(allowed, resolved_ip_or_None)``.

        * Zone A/B hostnames → resolve and return the IP.
        * Zone C hostnames → block without resolving.
        """
        from shared.enums import NetworkZone

        zone = self._enforcer.classify_zone(hostname)

        if zone == NetworkZone.EXTERNAL:
            self._sov_logger.log_event(
                event_type=SovereigntyEventType.DNS_BLOCKED,
                severity=SovereigntyEventSeverity.WARNING,
                source_component="dns_monitor",
                detail=f"DNS query blocked for external host: {hostname}",
                metadata={"hostname": hostname, "zone": zone.value},
            )
            return False, None

        # Zone A or Zone B — resolve
        resolved = self._safe_resolve(hostname)

        self._sov_logger.log_event(
            event_type=SovereigntyEventType.DNS_QUERY,
            severity=SovereigntyEventSeverity.INFO,
            source_component="dns_monitor",
            detail=f"DNS resolved {hostname} → {resolved}",
            metadata={
                "hostname": hostname,
                "resolved": resolved,
                "zone": zone.value,
            },
        )
        return True, resolved

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _safe_resolve(hostname: str) -> Optional[str]:
        """Resolve *hostname* to an IPv4 address, or return ``None``."""
        try:
            return socket.gethostbyname(hostname)
        except (socket.gaierror, socket.herror, OSError):
            return None
