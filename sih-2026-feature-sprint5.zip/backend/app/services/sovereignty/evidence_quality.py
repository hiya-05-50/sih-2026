"""Sprint 5 – Evidence Extraction Quality Metrics.

Evaluates document/evidence extraction quality by comparing
extracted evidence objects against hand-annotated ground-truth
annotations.  Calculates precision, recall, and F1.

When no ground-truth data is available every metric is reported
as ``TO BE VALIDATED`` — no numbers are invented.
"""

from __future__ import annotations

from typing import Any, List, Optional

from pydantic import BaseModel, Field

from shared.enums import EvidenceType

# Re-use the sentinel from the SIAB harness.
TO_BE_VALIDATED = "TO BE VALIDATED"


# ------------------------------------------------------------------
# Data models
# ------------------------------------------------------------------


class GroundTruthAnnotation(BaseModel):
    """A single hand-annotated ground-truth item.

    Each annotation describes one piece of evidence that *should*
    be extracted from a document.
    """

    label: str = Field(
        ..., description="Human-readable label, e.g. 'pressure_reading'."
    )
    evidence_type: EvidenceType = Field(
        ..., description="Expected evidence type."
    )
    expected_text_fragment: Optional[str] = Field(
        default=None,
        description=(
            "Optional substring expected in the extracted text. "
            "If provided, a match requires both type AND text."
        ),
    )


class EvidenceQualityResult(BaseModel):
    """Result of an extraction-quality evaluation."""

    precision: Any = Field(default=TO_BE_VALIDATED)
    recall: Any = Field(default=TO_BE_VALIDATED)
    f1_score: Any = Field(default=TO_BE_VALIDATED)
    true_positives: int = 0
    false_positives: int = 0
    false_negatives: int = 0
    total_extracted: int = 0
    total_ground_truth: int = 0
    matched_labels: List[str] = Field(default_factory=list)
    unmatched_labels: List[str] = Field(default_factory=list)


# ------------------------------------------------------------------
# Evaluator
# ------------------------------------------------------------------


class EvidenceQualityEvaluator:
    """Compares extracted evidence against ground truth.

    Usage::

        evaluator = EvidenceQualityEvaluator()

        # With ground truth → real metrics
        result = evaluator.evaluate(extracted_evidence, annotations)

        # Without ground truth → TO BE VALIDATED
        result = evaluator.evaluate(extracted_evidence, None)
    """

    def evaluate(
        self,
        extracted: List[Any],
        ground_truth: Optional[List[GroundTruthAnnotation]],
    ) -> EvidenceQualityResult:
        """Evaluate extraction quality.

        Parameters
        ----------
        extracted:
            Evidence objects produced by the extraction pipeline.
            Each must have ``.evidence_type`` and ``.extracted_text``.
        ground_truth:
            Hand-annotated annotations.  If ``None`` or empty,
            all metrics are ``TO BE VALIDATED``.

        Returns
        -------
        EvidenceQualityResult with precision, recall, F1 (or sentinel).
        """
        if not ground_truth:
            return EvidenceQualityResult(
                total_extracted=len(extracted),
                total_ground_truth=0,
            )

        # Track which ground-truth annotations were matched
        matched: list[str] = []
        unmatched: list[str] = []
        gt_matched_flags = [False] * len(ground_truth)

        for ann_idx, ann in enumerate(ground_truth):
            found = False
            for ev in extracted:
                if self._matches(ev, ann):
                    found = True
                    break
            if found:
                matched.append(ann.label)
                gt_matched_flags[ann_idx] = True
            else:
                unmatched.append(ann.label)

        tp = len(matched)
        fn = len(unmatched)
        # FP = extracted items that matched no ground truth annotation
        fp = max(0, len(extracted) - tp)

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else 0.0
        )

        return EvidenceQualityResult(
            precision=round(precision, 4),
            recall=round(recall, 4),
            f1_score=round(f1, 4),
            true_positives=tp,
            false_positives=fp,
            false_negatives=fn,
            total_extracted=len(extracted),
            total_ground_truth=len(ground_truth),
            matched_labels=matched,
            unmatched_labels=unmatched,
        )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _matches(evidence: Any, annotation: GroundTruthAnnotation) -> bool:
        """Return ``True`` if *evidence* satisfies *annotation*."""
        # Must match evidence type
        ev_type = getattr(evidence, "evidence_type", None)
        if ev_type is None:
            return False

        # Compare as strings for robustness with enum vs str
        if str(ev_type) != str(annotation.evidence_type):
            if getattr(ev_type, "value", ev_type) != getattr(
                annotation.evidence_type, "value", annotation.evidence_type
            ):
                return False

        # If a text fragment is specified, it must appear in the text
        if annotation.expected_text_fragment is not None:
            ev_text = getattr(evidence, "extracted_text", "") or ""
            if annotation.expected_text_fragment.lower() not in ev_text.lower():
                return False

        return True
