"""Sprint 5 – Network Zone Enforcer.

Classifies outbound destinations into three zones and enforces
allow/deny policy.  Every decision is logged through the
SovereigntyLogger so that all network activity is observable.

Zones
-----
Zone A — LOOPBACK   (127.0.0.0/8, ::1, localhost)        → ALLOW
Zone B — TRUSTED    (explicit allowlist of hosts/IPs)     → ALLOW
Zone C — EXTERNAL   (everything else)                     → DENY

Nothing is trusted merely because it is on a private/RFC-1918 range.
Zone B membership requires *explicit* configuration.
"""

from __future__ import annotations

import ipaddress
import logging
from typing import List, Optional

from shared.enums import (
    NetworkZone,
    SovereigntyEventSeverity,
    SovereigntyEventType,
)
from app.services.sovereignty.sovereignty_logger import SovereigntyLogger

logger = logging.getLogger(__name__)


class NetworkEnforcer:
    """Stateless network zone classifier and outbound gate.

    Parameters
    ----------
    sovereignty_logger:
        The sovereignty logger to record every allow/deny decision.
    trusted_hosts:
        Explicit allowlist of trusted on-premise hosts and IPs
        (Zone B).  Each entry is matched literally after
        lower-casing and stripping whitespace.
    """

    def __init__(
        self,
        sovereignty_logger: SovereigntyLogger,
        trusted_hosts: Optional[List[str]] = None,
    ) -> None:
        self._sov_logger = sovereignty_logger
        self._trusted_hosts: set[str] = {
            h.strip().lower() for h in (trusted_hosts or [])
        }

    # ------------------------------------------------------------------
    # Zone classification
    # ------------------------------------------------------------------

    def classify_zone(self, host: str) -> NetworkZone:
        """Classify *host* (IP or hostname) into a network zone.

        Returns ``NetworkZone.LOOPBACK``, ``TRUSTED_ONPREM``,
        or ``EXTERNAL``.
        """
        normalized = host.strip().lower()

        if self._is_loopback(normalized):
            return NetworkZone.LOOPBACK

        if normalized in self._trusted_hosts:
            return NetworkZone.TRUSTED_ONPREM

        return NetworkZone.EXTERNAL

    # ------------------------------------------------------------------
    # Outbound enforcement
    # ------------------------------------------------------------------

    def check_outbound(
        self,
        host: str,
        port: int = 0,
        source_component: str = "network_enforcer",
    ) -> bool:
        """Decide whether an outbound connection is allowed.

        Returns ``True`` (allowed) for Zone A and Zone B,
        ``False`` (denied) for Zone C.  Every decision is
        recorded in the sovereignty log.
        """
        zone = self.classify_zone(host)
        metadata = {"host": host, "port": port, "zone": zone.value}

        if zone in (NetworkZone.LOOPBACK, NetworkZone.TRUSTED_ONPREM):
            self._sov_logger.log_event(
                event_type=SovereigntyEventType.NETWORK_ALLOWED,
                severity=SovereigntyEventSeverity.INFO,
                source_component=source_component,
                detail=f"Allowed outbound → {host}:{port} (zone={zone.value})",
                metadata=metadata,
            )
            return True

        # Zone C → DENY
        self._sov_logger.log_event(
            event_type=SovereigntyEventType.NETWORK_BLOCKED,
            severity=SovereigntyEventSeverity.CRITICAL,
            source_component=source_component,
            detail=f"BLOCKED outbound → {host}:{port} (zone={zone.value})",
            metadata=metadata,
        )
        return False

    # ------------------------------------------------------------------
    # Trusted-host management
    # ------------------------------------------------------------------

    def add_trusted_host(self, host: str) -> None:
        """Add a host/IP to the Zone B allowlist at runtime."""
        self._trusted_hosts.add(host.strip().lower())

    def remove_trusted_host(self, host: str) -> None:
        """Remove a host/IP from the Zone B allowlist."""
        self._trusted_hosts.discard(host.strip().lower())

    @property
    def trusted_hosts(self) -> frozenset[str]:
        """Return an immutable snapshot of the current allowlist."""
        return frozenset(self._trusted_hosts)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_loopback(host: str) -> bool:
        """Return ``True`` if *host* is a loopback address."""
        if host in ("localhost", "127.0.0.1", "::1"):
            return True
        try:
            addr = ipaddress.ip_address(host)
            return addr.is_loopback
        except ValueError:
            # Not a valid IP literal — fall through
            return False
