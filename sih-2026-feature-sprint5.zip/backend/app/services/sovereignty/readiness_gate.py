"""Sprint 5 – Sovereignty Readiness Gate and Self-Test.

Reports ``SOVEREIGNTY = VERIFIED`` **only** when every required
control is active and the controlled self-test passes.  If any
single condition fails the status is ``SOVEREIGNTY = NOT VERIFIED``.

Required conditions
-------------------
1. Outbound enforcement is active  (NetworkEnforcer present)
2. Default-deny policy is active   (Zone C → DENY)
3. DNS monitoring is active        (DNSMonitor present)
4. Outbound monitoring is active   (SovereigntyLogger present)
5. No mandatory external dependency
6. Controlled self-test passed     (blocked outbound is observable)
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, List, Optional

from pydantic import BaseModel, Field

from shared.enums import (
    SovereigntyEventSeverity,
    SovereigntyEventType,
    SovereigntyState,
)
from app.services.sovereignty.sovereignty_logger import SovereigntyLogger

logger = logging.getLogger(__name__)

# Status strings — never modified at runtime.
SOVEREIGNTY_VERIFIED = "SOVEREIGNTY = VERIFIED"
SOVEREIGNTY_NOT_VERIFIED = "SOVEREIGNTY = NOT VERIFIED"

# Self-test probe destination — a clearly-invalid external host.
_SELF_TEST_HOST = "self-test.external.invalid"
_SELF_TEST_PORT = 443


# ------------------------------------------------------------------
# Data models
# ------------------------------------------------------------------


class ReadinessCondition(BaseModel):
    """One readiness-gate check."""

    name: str
    passed: bool
    detail: str = ""


class SelfTestResult(BaseModel):
    """Result of the controlled sovereignty self-test."""

    passed: bool = False
    outbound_blocked: bool = False
    block_logged: bool = False
    detail: str = ""
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class ReadinessReport(BaseModel):
    """Full readiness-gate report."""

    sovereignty_status: str = SOVEREIGNTY_NOT_VERIFIED
    state: SovereigntyState = SovereigntyState.NOT_READY
    conditions: List[ReadinessCondition] = Field(default_factory=list)
    all_passed: bool = False
    self_test: Optional[SelfTestResult] = None
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ------------------------------------------------------------------
# Readiness Gate
# ------------------------------------------------------------------


class SovereigntyReadinessGate:
    """Checks all sovereignty controls and reports status.

    Parameters
    ----------
    sovereignty_logger:
        Required.  Used for logging readiness changes and
        verifying that outbound monitoring is active.
    network_enforcer:
        The network enforcer (Task 2).  ``None`` means
        outbound enforcement is NOT active.
    dns_monitor:
        The DNS monitor (Task 2).  ``None`` means DNS
        monitoring is NOT active.
    external_dependencies:
        List of mandatory external dependencies.  Must be
        empty for sovereignty to be verified.
    """

    def __init__(
        self,
        sovereignty_logger: SovereigntyLogger,
        network_enforcer: Any = None,
        dns_monitor: Any = None,
        external_dependencies: Optional[List[str]] = None,
    ) -> None:
        self._sov_logger = sovereignty_logger
        self._enforcer = network_enforcer
        self._dns_monitor = dns_monitor
        self._external_deps = external_dependencies or []
        self._last_self_test: Optional[SelfTestResult] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check_readiness(self) -> ReadinessReport:
        """Evaluate all conditions and produce a readiness report.

        Returns ``SOVEREIGNTY = VERIFIED`` only when **every**
        condition passes.  Otherwise ``SOVEREIGNTY = NOT VERIFIED``.
        """
        conditions: list[ReadinessCondition] = [
            self._check_outbound_enforcement(),
            self._check_deny_policy(),
            self._check_dns_monitoring(),
            self._check_outbound_monitoring(),
            self._check_no_external_dependency(),
            self._check_self_test(),
        ]

        all_passed = all(c.passed for c in conditions)

        report = ReadinessReport(
            sovereignty_status=(
                SOVEREIGNTY_VERIFIED if all_passed
                else SOVEREIGNTY_NOT_VERIFIED
            ),
            state=(
                SovereigntyState.READY if all_passed
                else SovereigntyState.NOT_READY
            ),
            conditions=conditions,
            all_passed=all_passed,
            self_test=self._last_self_test,
        )

        # Log the readiness change
        self._sov_logger.log_event(
            event_type=SovereigntyEventType.READINESS_CHANGE,
            severity=(
                SovereigntyEventSeverity.INFO if all_passed
                else SovereigntyEventSeverity.WARNING
            ),
            source_component="readiness_gate",
            detail=report.sovereignty_status,
            metadata={
                "state": report.state.value,
                "all_passed": all_passed,
                "failed": [c.name for c in conditions if not c.passed],
            },
        )

        return report

    def run_self_test(self) -> SelfTestResult:
        """Run the controlled sovereignty self-test.

        1. Attempt an outbound connection to a known external host.
        2. Verify the enforcer blocks it.
        3. Verify the block was logged.

        The result is cached so ``check_readiness()`` can include it.
        """
        result = SelfTestResult()

        if self._enforcer is None:
            result.detail = "No network enforcer — cannot run self-test."
            self._last_self_test = result
            self._log_self_test(result)
            return result

        # Record event count before the probe
        before_count = self._sov_logger.event_count

        # Attempt outbound — must be DENIED
        allowed = self._enforcer.check_outbound(
            _SELF_TEST_HOST, _SELF_TEST_PORT,
            source_component="sovereignty_self_test",
        )

        result.outbound_blocked = not allowed

        # Check that the block was logged
        after_count = self._sov_logger.event_count
        if after_count > before_count:
            # Verify the most recent event is a NETWORK_BLOCKED for our host
            latest = self._sov_logger.get_latest()
            if (
                latest is not None
                and latest.event_type == SovereigntyEventType.NETWORK_BLOCKED
                and _SELF_TEST_HOST in latest.detail
            ):
                result.block_logged = True

        result.passed = result.outbound_blocked and result.block_logged

        if result.passed:
            result.detail = (
                f"Self-test PASSED: outbound to {_SELF_TEST_HOST}:{_SELF_TEST_PORT} "
                "was blocked and logged."
            )
        else:
            reasons = []
            if not result.outbound_blocked:
                reasons.append("outbound was NOT blocked")
            if not result.block_logged:
                reasons.append("block was NOT logged")
            result.detail = (
                f"Self-test FAILED: {'; '.join(reasons)}."
            )

        self._last_self_test = result
        self._log_self_test(result)
        return result

    # ------------------------------------------------------------------
    # Individual condition checks
    # ------------------------------------------------------------------

    def _check_outbound_enforcement(self) -> ReadinessCondition:
        active = self._enforcer is not None
        return ReadinessCondition(
            name="outbound_enforcement_active",
            passed=active,
            detail="NetworkEnforcer is present" if active
                   else "NetworkEnforcer is NOT configured",
        )

    def _check_deny_policy(self) -> ReadinessCondition:
        if self._enforcer is None:
            return ReadinessCondition(
                name="deny_policy_active",
                passed=False,
                detail="No enforcer — cannot verify deny policy",
            )
        # Probe: an external IP must be denied
        from shared.enums import NetworkZone
        zone = self._enforcer.classify_zone("198.51.100.1")  # TEST-NET-2
        denied = zone == NetworkZone.EXTERNAL
        return ReadinessCondition(
            name="deny_policy_active",
            passed=denied,
            detail="Zone C default-deny is active" if denied
                   else "Zone C default-deny is NOT active",
        )

    def _check_dns_monitoring(self) -> ReadinessCondition:
        active = self._dns_monitor is not None
        return ReadinessCondition(
            name="dns_monitoring_active",
            passed=active,
            detail="DNSMonitor is present" if active
                   else "DNSMonitor is NOT configured",
        )

    def _check_outbound_monitoring(self) -> ReadinessCondition:
        active = self._sov_logger is not None
        return ReadinessCondition(
            name="outbound_monitoring_active",
            passed=active,
            detail="SovereigntyLogger is active" if active
                   else "SovereigntyLogger is NOT configured",
        )

    def _check_no_external_dependency(self) -> ReadinessCondition:
        if self._external_deps:
            return ReadinessCondition(
                name="no_external_dependency",
                passed=False,
                detail=f"Mandatory external dependencies: {self._external_deps}",
            )
        return ReadinessCondition(
            name="no_external_dependency",
            passed=True,
            detail="No mandatory external dependencies",
        )

    def _check_self_test(self) -> ReadinessCondition:
        if self._last_self_test is None:
            return ReadinessCondition(
                name="self_test_passed",
                passed=False,
                detail="Self-test has not been run yet",
            )
        return ReadinessCondition(
            name="self_test_passed",
            passed=self._last_self_test.passed,
            detail=self._last_self_test.detail,
        )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _log_self_test(self, result: SelfTestResult) -> None:
        self._sov_logger.log_event(
            event_type=SovereigntyEventType.SELF_TEST_RESULT,
            severity=(
                SovereigntyEventSeverity.INFO if result.passed
                else SovereigntyEventSeverity.CRITICAL
            ),
            source_component="sovereignty_self_test",
            detail=result.detail,
            metadata={
                "passed": result.passed,
                "outbound_blocked": result.outbound_blocked,
                "block_logged": result.block_logged,
            },
        )
