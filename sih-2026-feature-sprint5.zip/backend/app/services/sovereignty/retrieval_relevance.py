"""Sprint 5 – Retrieval Relevance Metric.

Evaluates how well the retrieval system ranks relevant documents
for a given query.  Designed for SIAB Config 2 (generic agent +
tools, without SAFIRE Verification Fabric).

Metrics
-------
* **Precision@K** — fraction of retrieved items that are relevant.
* **Recall@K** — fraction of relevant items that were retrieved.
* **MRR** — Mean Reciprocal Rank: 1 / rank-of-first-relevant-result.

When no ground-truth relevance data is available every metric is
reported as ``TO BE VALIDATED``.  No scores are invented.
"""

from __future__ import annotations

from typing import Any, List, Optional

from pydantic import BaseModel, Field

TO_BE_VALIDATED = "TO BE VALIDATED"


# ------------------------------------------------------------------
# Data models
# ------------------------------------------------------------------


class RelevanceGroundTruth(BaseModel):
    """Ground-truth relevance judgements for a single query."""

    query: str = Field(..., description="The retrieval query.")
    relevant_ids: List[str] = Field(
        ...,
        description="IDs (evidence or document) that are relevant to the query.",
    )


class RetrievalRelevanceResult(BaseModel):
    """Result of a retrieval-relevance evaluation."""

    precision_at_k: Any = Field(default=TO_BE_VALIDATED)
    recall_at_k: Any = Field(default=TO_BE_VALIDATED)
    mrr: Any = Field(default=TO_BE_VALIDATED)
    k: int = 0
    total_retrieved: int = 0
    total_relevant: int = 0
    relevant_retrieved: int = 0
    retrieved_relevant_ids: List[str] = Field(default_factory=list)


# ------------------------------------------------------------------
# Evaluator
# ------------------------------------------------------------------


class RetrievalRelevanceEvaluator:
    """Compares a ranked list of retrieved IDs against ground truth.

    Usage::

        evaluator = RetrievalRelevanceEvaluator()

        # With ground truth → real metrics
        result = evaluator.evaluate(retrieved_ids, ground_truth)

        # Without ground truth → TO BE VALIDATED
        result = evaluator.evaluate(retrieved_ids, None)
    """

    def evaluate(
        self,
        retrieved_ids: List[str],
        ground_truth: Optional[RelevanceGroundTruth],
    ) -> RetrievalRelevanceResult:
        """Evaluate retrieval relevance.

        Parameters
        ----------
        retrieved_ids:
            Ranked list of IDs returned by the retrieval system
            (first = highest rank).
        ground_truth:
            Relevance judgements.  If ``None`` or has an empty
            ``relevant_ids`` list, all metrics are ``TO BE VALIDATED``.

        Returns
        -------
        RetrievalRelevanceResult
        """
        if ground_truth is None or not ground_truth.relevant_ids:
            return RetrievalRelevanceResult(
                total_retrieved=len(retrieved_ids),
            )

        relevant_set = set(ground_truth.relevant_ids)
        k = len(retrieved_ids)

        # Identify which retrieved items are relevant
        hits = [rid for rid in retrieved_ids if rid in relevant_set]
        relevant_retrieved = len(hits)

        # Precision@K
        precision = relevant_retrieved / k if k > 0 else 0.0

        # Recall@K
        recall = (
            relevant_retrieved / len(relevant_set)
            if len(relevant_set) > 0
            else 0.0
        )

        # MRR — reciprocal rank of the first relevant result
        mrr = 0.0
        for rank, rid in enumerate(retrieved_ids, start=1):
            if rid in relevant_set:
                mrr = 1.0 / rank
                break

        return RetrievalRelevanceResult(
            precision_at_k=round(precision, 4),
            recall_at_k=round(recall, 4),
            mrr=round(mrr, 4),
            k=k,
            total_retrieved=k,
            total_relevant=len(relevant_set),
            relevant_retrieved=relevant_retrieved,
            retrieved_relevant_ids=hits,
        )
