"""Sprint 5 – SIAB (Sovereign Intelligence Assurance Benchmark) Harness.

Provides a harness to run a *fixed* benchmark task across three
configurations so the comparison is fair:

  Config 1  BARE_MODEL       — Single strong local model, no scaffolding.
                               Bare gateway invocation for the baseline.
  Config 2  AGENT_NO_FABRIC  — Generic agent + tools, but without
                               SAFIRE's Verification Fabric.
  Config 3  FULL_SAFIRE      — Complete SAFIRE pipeline including
                               verification, deterministic compute,
                               and artifact generation.

Every metric is recorded honestly:
  • Measured values → stored as numbers.
  • Not-yet-measured values → stored as the sentinel ``TO_BE_VALIDATED``.

No benchmark numbers are invented.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from shared.enums import SIABConfig

logger = logging.getLogger(__name__)

# Sentinel for unmeasured metrics
TO_BE_VALIDATED = "TO BE VALIDATED"

# The fixed benchmark prompt used for all three configurations.
SIAB_BENCHMARK_PROMPT = (
    "Analyze the following inspection report excerpt and determine "
    "whether the pressure reading of 4.2 Bar (threshold ≤ 5.0 Bar) "
    "passes compliance.  Return a structured JSON object with fields: "
    "parameter, value, threshold, status."
)


# ------------------------------------------------------------------
# Data models
# ------------------------------------------------------------------


class SIABMetrics(BaseModel):
    """Metrics captured for a single SIAB configuration run."""

    latency_ms: Any = Field(
        default=TO_BE_VALIDATED,
        description="End-to-end latency in milliseconds.",
    )
    response_text: Optional[str] = Field(
        default=None,
        description="Raw response text from the model/pipeline.",
    )
    accuracy: Any = Field(
        default=TO_BE_VALIDATED,
        description="Whether the answer was factually correct (bool or TO BE VALIDATED).",
    )
    evidence_count: Any = Field(
        default=TO_BE_VALIDATED,
        description="Number of evidence objects produced (Config 3 only).",
    )
    verification_passed: Any = Field(
        default=TO_BE_VALIDATED,
        description="Whether verification fabric checks passed (Config 3 only).",
    )
    artifacts_generated: Any = Field(
        default=TO_BE_VALIDATED,
        description="Number of artifacts generated (Config 3 only).",
    )
    evidence_quality: Any = Field(
        default=TO_BE_VALIDATED,
        description="Evidence extraction quality metrics (Config 3, requires ground truth).",
    )
    retrieval_relevance: Any = Field(
        default=TO_BE_VALIDATED,
        description="Retrieval relevance metrics (Config 2, requires ground truth).",
    )


class SIABRunResult(BaseModel):
    """Result of a single SIAB configuration run."""

    run_id: str = Field(
        default_factory=lambda: f"siab-{uuid.uuid4().hex[:8]}"
    )
    config: SIABConfig
    prompt: str = SIAB_BENCHMARK_PROMPT
    metrics: SIABMetrics = Field(default_factory=SIABMetrics)
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    error: Optional[str] = None


class SIABReport(BaseModel):
    """Comparative report across all three SIAB configurations."""

    report_id: str = Field(
        default_factory=lambda: f"siab-report-{uuid.uuid4().hex[:8]}"
    )
    benchmark_prompt: str = SIAB_BENCHMARK_PROMPT
    runs: Dict[str, SIABRunResult] = Field(default_factory=dict)
    generated_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ------------------------------------------------------------------
# SIAB Harness
# ------------------------------------------------------------------


class SIABHarness:
    """Runs the SIAB benchmark across all three configurations.

    Parameters
    ----------
    adapter_manager:
        Used by Config 1 (bare model) and Config 2 (agent + tools).
        May be ``None`` when only running Config 3 or in tests.
    flagship_pipeline:
        Used by Config 3 (full SAFIRE pipeline).
        May be ``None`` when only running Config 1/2 or in tests.
    """

    def __init__(
        self,
        adapter_manager: Any = None,
        flagship_pipeline: Any = None,
    ) -> None:
        self._adapter_manager = adapter_manager
        self._flagship_pipeline = flagship_pipeline
        self._history: list[SIABReport] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_supported_configs(self) -> list[SIABConfig]:
        """Return the list of supported SIAB configurations."""
        return [
            SIABConfig.BARE_MODEL,
            SIABConfig.AGENT_NO_FABRIC,
            SIABConfig.FULL_SAFIRE,
        ]

    async def run_config(self, config: SIABConfig) -> SIABRunResult:
        """Run the benchmark for a single configuration.

        Returns a ``SIABRunResult`` with measured or ``TO_BE_VALIDATED``
        metrics.
        """
        result = SIABRunResult(config=config)

        try:
            if config == SIABConfig.BARE_MODEL:
                result = await self._run_bare_model(result)
            elif config == SIABConfig.AGENT_NO_FABRIC:
                result = await self._run_agent_no_fabric(result)
            elif config == SIABConfig.FULL_SAFIRE:
                result = await self._run_full_safire(result)
            else:
                result.error = f"Unknown SIAB config: {config}"
        except Exception as exc:
            result.error = str(exc)
            logger.error("SIAB [%s] %s failed: %s", result.run_id, config, exc)

        return result

    async def run_all(self) -> SIABReport:
        """Run the benchmark across all three configurations.

        Returns a ``SIABReport`` with one ``SIABRunResult`` per config.
        """
        report = SIABReport()

        for config in self.get_supported_configs():
            run_result = await self.run_config(config)
            report.runs[config.value] = run_result
            logger.info(
                "SIAB [%s] %s → latency=%s",
                run_result.run_id,
                config.value,
                run_result.metrics.latency_ms,
            )

        self._history.append(report)
        return report

    def get_history(self) -> list[SIABReport]:
        """Return all past SIAB reports."""
        return list(self._history)

    # ------------------------------------------------------------------
    # Config 1: Bare model — single gateway invocation
    # ------------------------------------------------------------------

    async def _run_bare_model(self, result: SIABRunResult) -> SIABRunResult:
        """Config 1: invoke the model directly, no tools or scaffolding."""
        if self._adapter_manager is None:
            # No adapter available — record structure with TO BE VALIDATED
            result.metrics = SIABMetrics()
            return result

        from app.schemas.adapter import GenerateRequest

        # Pick the first available adapter
        adapters = list(self._adapter_manager._adapters.values()) if hasattr(
            self._adapter_manager, "_adapters"
        ) else []

        if not adapters:
            # Try to get one via the registry
            adapter = None
            if hasattr(self._adapter_manager, "_registry"):
                models = self._adapter_manager._registry.list_all()
                if models:
                    adapter = self._adapter_manager.get_adapter(models[0].model_id)
            if adapter is None:
                result.metrics = SIABMetrics()
                return result
        else:
            adapter = adapters[0]

        request = GenerateRequest(
            prompt=SIAB_BENCHMARK_PROMPT,
            temperature=0.1,
            max_tokens=200,
        )

        start = time.perf_counter()
        response = await adapter.generate(request)
        elapsed_ms = (time.perf_counter() - start) * 1000

        result.metrics.latency_ms = round(elapsed_ms, 2)
        result.metrics.response_text = response.text
        # Accuracy requires human evaluation — cannot be auto-measured
        result.metrics.accuracy = TO_BE_VALIDATED
        # Config 1 has no evidence, verification, or artifacts
        result.metrics.evidence_count = 0
        result.metrics.verification_passed = "N/A"
        result.metrics.artifacts_generated = 0

        return result

    # ------------------------------------------------------------------
    # Config 2: Agent + tools, no verification fabric
    # ------------------------------------------------------------------

    async def _run_agent_no_fabric(
        self, result: SIABRunResult
    ) -> SIABRunResult:
        """Config 2: agent with tools but no SAFIRE verification."""
        if self._adapter_manager is None:
            result.metrics = SIABMetrics()
            return result

        from app.schemas.adapter import GenerateRequest

        # Use the adapter with a tool-calling prompt to simulate
        # an agent that has tools but no verification fabric.
        adapter = None
        if hasattr(self._adapter_manager, "_registry"):
            models = self._adapter_manager._registry.list_all()
            for m in models:
                if m.tool_calling:
                    adapter = self._adapter_manager.get_adapter(m.model_id)
                    break
            if adapter is None and models:
                adapter = self._adapter_manager.get_adapter(models[0].model_id)

        if adapter is None:
            result.metrics = SIABMetrics()
            return result

        request = GenerateRequest(
            prompt=SIAB_BENCHMARK_PROMPT,
            system_prompt=(
                "You are an AI agent with access to tools. "
                "Analyze the request and provide a structured answer."
            ),
            temperature=0.1,
            max_tokens=200,
        )

        start = time.perf_counter()
        response = await adapter.generate(request)
        elapsed_ms = (time.perf_counter() - start) * 1000

        result.metrics.latency_ms = round(elapsed_ms, 2)
        result.metrics.response_text = response.text
        result.metrics.accuracy = TO_BE_VALIDATED
        # Config 2 has no verification fabric or artifact generation
        result.metrics.evidence_count = 0
        result.metrics.verification_passed = "N/A"
        result.metrics.artifacts_generated = 0

        return result

    # ------------------------------------------------------------------
    # Config 3: Full SAFIRE pipeline
    # ------------------------------------------------------------------

    async def _run_full_safire(self, result: SIABRunResult) -> SIABRunResult:
        """Config 3: full SAFIRE pipeline with verification fabric."""
        if self._flagship_pipeline is None:
            result.metrics = SIABMetrics()
            return result

        start = time.perf_counter()
        execution = await self._flagship_pipeline.execute()
        elapsed_ms = (time.perf_counter() - start) * 1000

        result.metrics.latency_ms = round(elapsed_ms, 2)
        result.metrics.evidence_count = execution.evidence_count
        result.metrics.accuracy = TO_BE_VALIDATED

        if execution.verification_report is not None:
            result.metrics.verification_passed = (
                execution.verification_report.overall_outcome == "PASS"
            )
        else:
            result.metrics.verification_passed = TO_BE_VALIDATED

        if execution.artifact_manifest is not None:
            result.metrics.artifacts_generated = len(
                execution.artifact_manifest.artifacts
            )
        else:
            result.metrics.artifacts_generated = 0

        return result
