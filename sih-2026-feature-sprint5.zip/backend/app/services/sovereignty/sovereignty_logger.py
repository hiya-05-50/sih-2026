from __future__ import annotations

"""Sprint 5 – Sovereignty Event Logger.

Provides the central event bus for all sovereignty enforcement components.
Every Sprint 5 component (network enforcer, DNS monitor, tool guard,
prompt guard, sandbox guard, readiness gate, self-test) emits structured
events through this logger.

Events are stored in an in-memory ring buffer with a configurable
maximum capacity.  The logger provides filtering by event type and
time range, plus an aggregate summary for dashboard consumption.
"""

import logging
import threading
import uuid
from collections import deque
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from shared.enums import (
    SovereigntyEventSeverity,
    SovereigntyEventType,
)

logger = logging.getLogger(__name__)

# Default ring-buffer capacity
_DEFAULT_MAX_EVENTS = 2000


class SovereigntyEvent(BaseModel):
    """A single sovereignty event record."""

    event_id: str = Field(
        default_factory=lambda: f"sev-{uuid.uuid4().hex[:12]}",
        description="Unique event identifier",
    )
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
        description="ISO-8601 UTC timestamp",
    )
    event_type: SovereigntyEventType = Field(
        ..., description="Categorised event type"
    )
    severity: SovereigntyEventSeverity = Field(
        default=SovereigntyEventSeverity.INFO,
        description="Event severity level",
    )
    source_component: str = Field(
        ..., description="Component that emitted the event (e.g. 'network_enforcer')"
    )
    detail: str = Field(
        default="", description="Human-readable description"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Arbitrary structured payload",
    )


class SovereigntyEventSummary(BaseModel):
    """Aggregate summary of sovereignty events for dashboard display."""

    total_events: int = 0
    counts_by_type: Dict[str, int] = Field(default_factory=dict)
    counts_by_severity: Dict[str, int] = Field(default_factory=dict)
    latest_event: Optional[SovereigntyEvent] = None
    critical_count: int = 0
    warning_count: int = 0


class SovereigntyLogger:
    """Thread-safe sovereignty event logger with fixed-capacity ring buffer.

    Usage::

        sov_logger = SovereigntyLogger()
        sov_logger.log_event(
            event_type=SovereigntyEventType.STARTUP,
            severity=SovereigntyEventSeverity.INFO,
            source_component="main",
            detail="SAFIRE backend started",
        )
    """

    def __init__(self, max_events: int = _DEFAULT_MAX_EVENTS) -> None:
        self._max_events = max_events
        self._events: deque[SovereigntyEvent] = deque(maxlen=max_events)
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Event emission
    # ------------------------------------------------------------------

    def log_event(
        self,
        event_type: SovereigntyEventType,
        severity: SovereigntyEventSeverity = SovereigntyEventSeverity.INFO,
        source_component: str = "unknown",
        detail: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> SovereigntyEvent:
        """Create and store a sovereignty event.

        Returns the created event for caller convenience (e.g. to
        include the ``event_id`` in a log message).
        """
        event = SovereigntyEvent(
            event_type=event_type,
            severity=severity,
            source_component=source_component,
            detail=detail,
            metadata=metadata or {},
        )
        with self._lock:
            self._events.append(event)

        # Also emit to the standard Python logger so sovereignty events
        # appear in structured application logs.
        py_level = {
            SovereigntyEventSeverity.INFO: logging.INFO,
            SovereigntyEventSeverity.WARNING: logging.WARNING,
            SovereigntyEventSeverity.CRITICAL: logging.CRITICAL,
        }.get(severity, logging.INFO)
        logger.log(
            py_level,
            "Sovereignty [%s] %s: %s",
            severity,
            event_type,
            detail or "(no detail)",
        )

        return event

    # ------------------------------------------------------------------
    # Query / filtering
    # ------------------------------------------------------------------

    def get_events(
        self,
        event_type: Optional[SovereigntyEventType] = None,
        severity: Optional[SovereigntyEventSeverity] = None,
        since: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[SovereigntyEvent]:
        """Return events matching the given filters.

        Parameters
        ----------
        event_type:
            If provided, include only events of this type.
        severity:
            If provided, include only events of this severity.
        since:
            If provided, include only events whose ``timestamp`` is >=
            this ISO-8601 string.  Comparison is lexicographic (which is
            correct for ISO-8601 UTC strings).
        limit:
            Maximum number of events to return (most recent first).
        """
        with self._lock:
            snapshot = list(self._events)

        # Apply filters
        if event_type is not None:
            snapshot = [e for e in snapshot if e.event_type == event_type]
        if severity is not None:
            snapshot = [e for e in snapshot if e.severity == severity]
        if since is not None:
            snapshot = [e for e in snapshot if e.timestamp >= since]

        # Most recent first
        snapshot.reverse()

        if limit is not None:
            snapshot = snapshot[:limit]

        return snapshot

    def get_latest(self) -> Optional[SovereigntyEvent]:
        """Return the single most recent event, or ``None``."""
        with self._lock:
            return self._events[-1] if self._events else None

    # ------------------------------------------------------------------
    # Summary / aggregation
    # ------------------------------------------------------------------

    def get_summary(self) -> SovereigntyEventSummary:
        """Return an aggregate summary of all buffered events."""
        with self._lock:
            snapshot = list(self._events)

        counts_by_type: Dict[str, int] = {}
        counts_by_severity: Dict[str, int] = {}
        critical_count = 0
        warning_count = 0

        for event in snapshot:
            counts_by_type[event.event_type] = (
                counts_by_type.get(event.event_type, 0) + 1
            )
            counts_by_severity[event.severity] = (
                counts_by_severity.get(event.severity, 0) + 1
            )
            if event.severity == SovereigntyEventSeverity.CRITICAL:
                critical_count += 1
            elif event.severity == SovereigntyEventSeverity.WARNING:
                warning_count += 1

        return SovereigntyEventSummary(
            total_events=len(snapshot),
            counts_by_type=counts_by_type,
            counts_by_severity=counts_by_severity,
            latest_event=snapshot[-1] if snapshot else None,
            critical_count=critical_count,
            warning_count=warning_count,
        )

    # ------------------------------------------------------------------
    # Housekeeping
    # ------------------------------------------------------------------

    @property
    def event_count(self) -> int:
        """Return the current number of buffered events."""
        with self._lock:
            return len(self._events)

    def clear(self) -> None:
        """Remove all buffered events."""
        with self._lock:
            self._events.clear()
