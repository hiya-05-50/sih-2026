"""SAFIRE integration tests."""
